package fr.ubx.poo.ubomb.game;

public class GridException extends RuntimeException {
    public GridException(String message) {
        super(message);
    }
}
